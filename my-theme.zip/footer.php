<footer>
    <div class="footer-inner">

    </div>
</footer>
<?php wp_footer(); ?>
<!--システム・プラグイン用-->
</body>

</html>