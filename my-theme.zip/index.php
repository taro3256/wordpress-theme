<?php get_header(); ?>
<div class="container">
  <div class="contents">
 
  </div>
  <?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
