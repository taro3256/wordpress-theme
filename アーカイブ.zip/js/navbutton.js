jQuery(function() {
  jQuery("#navbutton").click(function() {
      jQuery("#header-nav").slideToggle();
  });
});
