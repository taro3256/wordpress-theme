<aside id="sidebar">
  <div class="sidebar-inner">
    <?php dynamic_sidebar( 'side-widget' ); ?>
  </div>
</aside>
